/*next.config.js*/
module.exports = {
  poweredByHeader: false
};
